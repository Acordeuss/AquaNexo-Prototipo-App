# START HERE — AquaNexo

Esta versión contiene el código de los **checkpoints 01 a 09** de la segunda evaluación.

## 1. Descomprimir fuera de OneDrive

Ruta sugerida:

```text
C:\Proyectos\AquaNexo
```

Evitar OneDrive reduce problemas de archivos bloqueados durante las compilaciones de Gradle.

## 2. Abrir en Android Studio

1. Android Studio → **Open**.
2. Selecciona la carpeta raíz `AquaNexo`.
3. Configura **Gradle JDK = Embedded JDK / JDK 17**.
4. Ejecuta **Sync Project with Gradle Files**.
5. Instala el SDK solicitado por Android Studio si corresponde.
6. Ejecuta **Build → Make Project**.

## 3. Gradle Wrapper

El proyecto incluye `gradle-wrapper.properties`, pero este ZIP no incluye el binario `gradle-wrapper.jar`.

Si tu IDE lo solicita, la forma más sencilla para alguien que recién trabaja con Android Studio es:

1. crear temporalmente un proyecto **Empty Activity**;
2. copiar desde ese proyecto:

```text
gradlew
gradlew.bat
gradle/wrapper/gradle-wrapper.jar
```

3. mantener el `gradle-wrapper.properties` de AquaNexo.

## 4. Primera ejecución

Credenciales:

```text
supervisor / 1234
admin / 1234
```

- Supervisor: puede crear pre-chequeos.
- Admin: solo consulta registros.

## 5. Prueba manual completa

Haz este recorrido con `supervisor`:

```text
Login
→ Nuevo pre-chequeo
→ Completar checklist
→ Adjuntar una foto desde galería
→ Salud del buzo
→ Resultado preliminar
→ Confirmar
→ Detalle
→ Post-chequeo
→ Historial
→ Buscar y filtrar
→ Cerrar y abrir la app
```

Los registros deben seguir almacenados gracias a Room.

## 6. Escenarios simples

### Cumple
- todos los ítems en OK o N/A;
- presión ficticia 120/80;
- SpO₂ 98;
- pulso 70;
- sin respuestas preventivas activadas.

### Observado
- un ítem no crítico en Obs.;
- agregar una observación de al menos 5 letras.

### Requiere revisión
- un ítem crítico en No; o
- SpO₂ ficticia 90.

## 7. Antes de subir a GitHub

Ejecuta primero Sync, Build y el flujo manual. Después:

```text
git add .
git commit -m "feat: completa flujo MVP de AquaNexo hasta checkpoint 09"
git push origin main
```

No subas `local.properties`, `.idea/`, archivos de build ni credenciales reales.
