# AquaNexo

**Seguridad y trazabilidad para operaciones de buceo**

AquaNexo es una aplicación Android *offline-first* desarrollada como proyecto académico para digitalizar el pre-chequeo de seguridad, el registro preventivo de salud, las evidencias fotográficas y la trazabilidad de faenas de buceo.

> **Proyecto académico.** Todos los usuarios, centros, buzos y parámetros utilizados en la demostración son ficticios. AquaNexo no representa un sistema oficial de AquaChile y sus resultados no constituyen diagnósticos médicos ni autorizaciones operacionales.

## Problema

El proceso manual en papel dificulta la trazabilidad, puede generar inconsistencias y retrasa la detección de condiciones que requieren revisión antes de una inmersión. El MVP busca concentrar ese recorrido en una aplicación móvil capaz de trabajar localmente incluso sin conexión.

## Objetivo del MVP

El flujo implementado permite:

- iniciar sesión con roles simulados;
- crear un pre-chequeo de faena;
- completar un checklist de seguridad de 17 ítems;
- registrar observaciones y evidencias mediante cámara o galería;
- ingresar parámetros preventivos de salud ficticios;
- calcular un resultado preliminar: **Cumple, Observado o Requiere revisión**;
- consultar el detalle del registro;
- completar un post-chequeo;
- buscar y filtrar registros desde el historial;
- conservar la información localmente con Room.

## Roles

| Rol | Permisos principales |
|---|---|
| **Supervisor de buceo** | Crear y continuar pre-chequeos, completar checklist, registrar salud, evidencias y post-chequeo. |
| **Jefe de centro / Admin** | Consultar inicio, historial y detalle de registros en modo lectura. |

## Arquitectura

```mermaid
flowchart LR
    UI[Jetpack Compose] -->|Eventos| VM[ViewModel + StateFlow]
    VM -->|UiState| UI
    VM --> R[Repository]
    R --> DAO[DAO]
    DAO --> ROOM[(Room / SQLite)]
    VM --> RULES[Reglas y validaciones]
```

La interfaz observa estados públicos de solo lectura. Los ViewModels coordinan acciones y validaciones, el Repository centraliza el acceso a datos y Room mantiene la persistencia local.

## Flujo principal

```mermaid
flowchart TD
    A[Login] --> B[Inicio / Dashboard]
    B --> C[Historial]
    B --> D[Nuevo pre-chequeo]
    D --> E[Checklist de seguridad + evidencias]
    E --> F[Salud del buzo]
    F --> G[Resultado preliminar]
    G --> H[Detalle]
    H --> I[Post-chequeo]
    I --> H
    C --> H
```

## Identidad visual

AquaNexo utiliza una paleta clara y técnica. Los colores de estado tienen significado funcional y no se usan solo como decoración.

| Función | Color |
|---|---|
| Principal | `#0B3D62` |
| Secundario | `#00A3C4` |
| Fondo | `#F3F7F9` |
| Texto principal | `#0F2430` |
| Cumple | `#17A75A` |
| Observado | `#D98A00` |
| Requiere revisión | `#DE3B40` |

## Tecnologías

- Kotlin
- Android Studio
- Jetpack Compose
- Material Design 3
- MVVM
- StateFlow
- Navigation Compose
- Room / SQLite
- KSP
- Coil
- Git y GitHub

## Conceptos trabajados en clases

### Validación de formularios

Las validaciones se concentran en `util/Reglas.kt`. Las pantallas entregan los datos al ViewModel y muestran los mensajes que recibe en `errores`.

### Manejo de estado con StateFlow

Los ViewModels utilizan `MutableStateFlow` privado y exponen `StateFlow` público. De esta forma solo el ViewModel modifica el estado y Compose se limita a observarlo.

### Filtros de búsqueda

`HistorialViewModel` conserva la búsqueda y el filtro de resultado dentro de su `UiState`. La lista `visibles` se calcula aplicando `filter()` sobre los registros observados desde Room.

## Estructura principal

```text
app/src/main/java/cl/duoc/aquanexo/
├── data/
│   ├── local/
│   │   ├── AquaNexoDatabase.kt
│   │   ├── Converters.kt
│   │   └── PreChequeoDao.kt
│   └── repository/
│       └── PreChequeoRepository.kt
├── model/
│   ├── Enums.kt
│   ├── ItemChequeo.kt
│   ├── PreChequeo.kt
│   └── Usuario.kt
├── navigation/
│   └── AppNavigation.kt
├── ui/
│   ├── components/
│   ├── screens/
│   └── theme/
├── util/
│   ├── Almacenamiento.kt
│   ├── DatosDemo.kt
│   └── Reglas.kt
└── viewmodel/
    ├── HistorialViewModel.kt
    ├── PreChequeoViewModel.kt
    └── SesionViewModel.kt
```

## Evaluación 2 — checkpoints 01 a 09

| Checkpoint | Contenido | Estado del código |
|---:|---|---|
| 01 | Proyecto base | ✅ Implementado |
| 02 | Modelos y reglas | ✅ Implementado |
| 03 | Tema y componentes | ✅ Implementado |
| 04 | Persistencia con Room | ✅ Implementado |
| 05 | Login, inicio y navegación | ✅ Implementado |
| 06 | Nuevo pre-chequeo, checklist y evidencias | ✅ Implementado |
| 07 | Salud del buzo | ✅ Implementado |
| 08 | Resultado y detalle | ✅ Implementado |
| 09 | Post-chequeo e historial | ✅ Implementado |

> Los checkpoints están implementados en el código entregado, pero deben verificarse con **Gradle Sync, Build y prueba manual en Android Studio** antes de marcar la evaluación como cerrada.

Los checkpoints **10 (pruebas formales)** y **11 (APK final / firmado)** se reservan para la tercera evaluación.

## Credenciales de demostración

```text
Supervisor
usuario: supervisor
clave:   1234

Jefe de centro / Admin
usuario: admin
clave:   1234
```

## Escenarios para demostrar

| Escenario | Resultado esperado |
|---|---|
| Todo OK + salud normal | Cumple |
| Ítem observado con justificación | Observado |
| Ítem crítico en No cumple | Requiere revisión |
| SpO₂ ficticia = 90 | Requiere revisión |
| Campos inválidos | Mensajes de validación |
| Historial | Búsqueda por buzo/centro/fecha y filtro por resultado |

## Documentación

- [`START_HERE.md`](START_HERE.md): cómo abrir y verificar el proyecto.
- [`docs/EVALUACION_2.md`](docs/EVALUACION_2.md): checklist de entrega.
- [`docs/ARQUITECTURA_Y_DEFENSA.md`](docs/ARQUITECTURA_Y_DEFENSA.md): explicación simple para la defensa.

## Pendiente visual

La retroalimentación anterior destacó la necesidad de presentar mejor el repositorio. Por eso los diseños finales deben quedar en:

```text
docs/diseno/
├── logo.png
├── flujo-usuario-uml.png
└── interfaces/
```

No se incluyen diseños ficticios en el repositorio solo para “rellenar”: las capturas deben corresponder a las interfaces que finalmente se utilicen o implementen.

## Privacidad

- Usar únicamente datos ficticios.
- No publicar antecedentes médicos, personales o internos reales.
- Las reglas de salud son simuladas para fines académicos.
- El resultado preliminar es un apoyo demostrativo, no una autorización oficial.

## Autor

**Carlos Leal**  
Equipo 12 · Desarrollo de Aplicaciones Móviles
