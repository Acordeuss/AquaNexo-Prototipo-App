package cl.duoc.aquanexo.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cl.duoc.aquanexo.model.Rol
import cl.duoc.aquanexo.ui.screens.ChecklistScreen
import cl.duoc.aquanexo.ui.screens.DetalleScreen
import cl.duoc.aquanexo.ui.screens.HistorialScreen
import cl.duoc.aquanexo.ui.screens.InicioScreen
import cl.duoc.aquanexo.ui.screens.LoginScreen
import cl.duoc.aquanexo.ui.screens.NuevoPreChequeoScreen
import cl.duoc.aquanexo.ui.screens.PostChequeoScreen
import cl.duoc.aquanexo.ui.screens.ResultadoScreen
import cl.duoc.aquanexo.ui.screens.SaludScreen
import cl.duoc.aquanexo.viewmodel.SesionViewModel

object Rutas {
    const val LOGIN = "login"
    const val INICIO = "inicio"
    const val HISTORIAL = "historial"
    const val NUEVO = "nuevo"
    const val CHECKLIST = "checklist/{id}"
    const val SALUD = "salud/{id}"
    const val RESULTADO = "resultado/{id}"
    const val DETALLE = "detalle/{id}"
    const val POST = "post/{id}"

    fun checklist(id: Long) = "checklist/$id"
    fun salud(id: Long) = "salud/$id"
    fun resultado(id: Long) = "resultado/$id"
    fun detalle(id: Long) = "detalle/$id"
    fun post(id: Long) = "post/$id"
}

private val argumentoId = listOf(
    navArgument("id") { type = NavType.LongType }
)

private fun NavBackStackEntry.id(): Long = arguments?.getLong("id") ?: 0L

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    val sesionVm: SesionViewModel = viewModel()
    val sesion by sesionVm.uiState.collectAsStateWithLifecycle()

    NavHost(
        navController = nav,
        startDestination = Rutas.LOGIN
    ) {
        composable(Rutas.LOGIN) {
            LoginScreen(sesionVm) {
                nav.navigate(Rutas.INICIO) {
                    popUpTo(Rutas.LOGIN) { inclusive = true }
                }
            }
        }

        composable(Rutas.INICIO) {
            sesion.usuario?.let { usuario ->
                InicioScreen(
                    usuario = usuario,
                    onNuevo = { nav.navigate(Rutas.NUEVO) },
                    onHistorial = {
                        nav.navigate(Rutas.HISTORIAL) { launchSingleTop = true }
                    },
                    onDetalle = { nav.navigate(Rutas.detalle(it)) },
                    onSalir = {
                        sesionVm.cerrarSesion()
                        nav.navigate(Rutas.LOGIN) {
                            popUpTo(Rutas.INICIO) { inclusive = true }
                        }
                    }
                )
            }
        }

        composable(Rutas.HISTORIAL) {
            HistorialScreen(
                onInicio = {
                    nav.popBackStack(Rutas.INICIO, inclusive = false)
                },
                onDetalle = { nav.navigate(Rutas.detalle(it)) }
            )
        }

        composable(Rutas.NUEVO) {
            sesion.usuario?.let { usuario ->
                NuevoPreChequeoScreen(
                    usuario = usuario,
                    onVolver = { nav.popBackStack() },
                    onCreado = { id ->
                        nav.navigate(Rutas.checklist(id)) {
                            popUpTo(Rutas.NUEVO) { inclusive = true }
                        }
                    }
                )
            }
        }

        composable(Rutas.CHECKLIST, arguments = argumentoId) { entry ->
            val id = entry.id()
            ChecklistScreen(
                id = id,
                onVolver = { nav.popBackStack() },
                onContinuar = { nav.navigate(Rutas.salud(id)) }
            )
        }

        composable(Rutas.SALUD, arguments = argumentoId) { entry ->
            val id = entry.id()
            SaludScreen(
                id = id,
                onVolver = { nav.popBackStack() },
                onContinuar = { nav.navigate(Rutas.resultado(id)) }
            )
        }

        composable(Rutas.RESULTADO, arguments = argumentoId) { entry ->
            val id = entry.id()
            ResultadoScreen(
                id = id,
                onVolver = { nav.popBackStack() },
                onConfirmado = {
                    nav.navigate(Rutas.detalle(id)) {
                        popUpTo(Rutas.INICIO)
                    }
                }
            )
        }

        composable(Rutas.DETALLE, arguments = argumentoId) { entry ->
            val id = entry.id()
            DetalleScreen(
                id = id,
                rol = sesion.usuario?.rol ?: Rol.ADMIN,
                onVolver = { nav.popBackStack() },
                onContinuar = { nav.navigate(Rutas.checklist(id)) },
                onPostChequeo = { nav.navigate(Rutas.post(id)) },
                onEliminado = { nav.popBackStack() }
            )
        }

        composable(Rutas.POST, arguments = argumentoId) { entry ->
            val id = entry.id()
            PostChequeoScreen(
                id = id,
                onVolver = { nav.popBackStack() },
                onGuardado = { nav.popBackStack() }
            )
        }
    }
}
