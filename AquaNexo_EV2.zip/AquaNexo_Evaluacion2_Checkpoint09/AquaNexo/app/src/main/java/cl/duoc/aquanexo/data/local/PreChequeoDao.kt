package cl.duoc.aquanexo.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import cl.duoc.aquanexo.model.EstadoItem
import cl.duoc.aquanexo.model.ItemChequeo
import cl.duoc.aquanexo.model.PreChequeo
import kotlinx.coroutines.flow.Flow

@Dao
interface PreChequeoDao {
    @Query("SELECT * FROM pre_chequeos ORDER BY id DESC")
    fun observarTodos(): Flow<List<PreChequeo>>

    @Query("SELECT * FROM pre_chequeos WHERE id = :id")
    fun observar(id: Long): Flow<PreChequeo?>

    @Query("SELECT * FROM items_chequeo WHERE preChequeoId = :id ORDER BY id")
    fun observarItems(id: Long): Flow<List<ItemChequeo>>

    @Insert
    suspend fun insertar(preChequeo: PreChequeo): Long

    @Insert
    suspend fun insertarItems(items: List<ItemChequeo>)

    @Update
    suspend fun actualizar(preChequeo: PreChequeo)

    @Query("UPDATE items_chequeo SET estado = :estado WHERE id = :itemId")
    suspend fun actualizarEstado(itemId: Long, estado: EstadoItem)

    @Query("UPDATE items_chequeo SET observacion = :texto WHERE id = :itemId")
    suspend fun actualizarObservacion(itemId: Long, texto: String)

    @Query("UPDATE items_chequeo SET fotoUri = :foto WHERE id = :itemId")
    suspend fun actualizarFoto(itemId: Long, foto: String)

    @Query("DELETE FROM pre_chequeos WHERE id = :id")
    suspend fun eliminar(id: Long)
}
