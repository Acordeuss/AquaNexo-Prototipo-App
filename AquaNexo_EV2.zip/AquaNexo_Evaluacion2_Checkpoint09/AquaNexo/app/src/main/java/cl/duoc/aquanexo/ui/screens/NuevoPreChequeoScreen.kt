package cl.duoc.aquanexo.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import cl.duoc.aquanexo.model.Usuario
import cl.duoc.aquanexo.ui.components.AppTopBar
import cl.duoc.aquanexo.ui.components.CampoTexto
import cl.duoc.aquanexo.ui.components.Selector
import cl.duoc.aquanexo.util.DatosDemo
import cl.duoc.aquanexo.util.Reglas
import cl.duoc.aquanexo.viewmodel.PreChequeoViewModel

@Composable
fun NuevoPreChequeoScreen(
    usuario: Usuario,
    onVolver: () -> Unit,
    onCreado: (Long) -> Unit,
    vm: PreChequeoViewModel = viewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    var centro by rememberSaveable { mutableStateOf("") }
    var buzo by rememberSaveable { mutableStateOf("") }
    var fecha by rememberSaveable { mutableStateOf(Reglas.fechaHoy()) }
    var hora by rememberSaveable { mutableStateOf(Reglas.horaAhora()) }

    Scaffold(
        topBar = { AppTopBar("Nuevo pre-chequeo", onVolver) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Datos generales de la faena")

            Selector(
                etiqueta = "Centro de operación",
                opciones = DatosDemo.centros,
                seleccion = centro,
                onSeleccion = { centro = it },
                error = state.errores["centro"]
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CampoTexto(
                    valor = fecha,
                    onCambio = { fecha = it },
                    etiqueta = "Fecha",
                    modifier = Modifier.weight(1f),
                    error = state.errores["fecha"]
                )
                CampoTexto(
                    valor = hora,
                    onCambio = { hora = it },
                    etiqueta = "Hora",
                    modifier = Modifier.weight(1f),
                    error = state.errores["hora"]
                )
            }

            Selector(
                etiqueta = "Buzo (ficticio)",
                opciones = DatosDemo.buzos,
                seleccion = buzo,
                onSeleccion = { buzo = it },
                error = state.errores["buzo"]
            )

            OutlinedTextField(
                value = usuario.nombre,
                onValueChange = {},
                readOnly = true,
                label = { Text("Supervisor responsable") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    vm.crear(
                        centro = centro,
                        fecha = fecha,
                        hora = hora,
                        buzo = buzo,
                        supervisor = usuario.nombre,
                        onCreado = onCreado
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Text("Crear y comenzar checklist")
            }
        }
    }
}
