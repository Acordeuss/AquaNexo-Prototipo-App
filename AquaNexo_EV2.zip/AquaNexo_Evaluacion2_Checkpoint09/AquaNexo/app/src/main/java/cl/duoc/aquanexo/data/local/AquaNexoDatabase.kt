package cl.duoc.aquanexo.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import cl.duoc.aquanexo.model.ItemChequeo
import cl.duoc.aquanexo.model.PreChequeo

@Database(
    entities = [PreChequeo::class, ItemChequeo::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AquaNexoDatabase : RoomDatabase() {
    abstract fun dao(): PreChequeoDao

    companion object {
        @Volatile
        private var instancia: AquaNexoDatabase? = null

        fun obtener(context: Context): AquaNexoDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AquaNexoDatabase::class.java,
                    "aquanexo.db"
                ).build().also { instancia = it }
            }
    }
}
