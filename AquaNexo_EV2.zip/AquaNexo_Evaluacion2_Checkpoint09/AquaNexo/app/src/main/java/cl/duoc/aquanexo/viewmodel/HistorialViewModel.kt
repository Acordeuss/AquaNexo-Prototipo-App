package cl.duoc.aquanexo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.aquanexo.AquaNexoApp
import cl.duoc.aquanexo.model.PreChequeo
import cl.duoc.aquanexo.model.Resultado
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HistorialUiState(
    val registros: List<PreChequeo> = emptyList(),
    val busqueda: String = "",
    val filtro: Resultado? = null
) {
    val visibles: List<PreChequeo>
        get() = registros.filter { registro ->
            val coincideResultado = filtro == null || registro.resultado == filtro
            val texto = busqueda.trim()
            val coincideTexto = texto.isEmpty() ||
                listOf(registro.buzo, registro.centro, registro.fecha).any {
                    it.contains(texto, ignoreCase = true)
                }

            coincideResultado && coincideTexto
        }
}

class HistorialViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as AquaNexoApp).repositorio

    private val _uiState = MutableStateFlow(HistorialUiState())
    val uiState: StateFlow<HistorialUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repo.todos().collect { lista ->
                _uiState.update { it.copy(registros = lista) }
            }
        }
    }

    fun buscar(texto: String) {
        _uiState.update { it.copy(busqueda = texto) }
    }

    fun filtrar(resultado: Resultado?) {
        _uiState.update { it.copy(filtro = resultado) }
    }
}
