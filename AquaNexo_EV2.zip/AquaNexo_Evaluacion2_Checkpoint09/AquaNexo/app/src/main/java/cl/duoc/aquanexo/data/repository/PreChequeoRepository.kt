package cl.duoc.aquanexo.data.repository

import androidx.room.withTransaction
import cl.duoc.aquanexo.data.local.AquaNexoDatabase
import cl.duoc.aquanexo.model.EstadoItem
import cl.duoc.aquanexo.model.ItemChequeo
import cl.duoc.aquanexo.model.PreChequeo
import cl.duoc.aquanexo.util.ChecklistBase

class PreChequeoRepository(private val db: AquaNexoDatabase) {
    private val dao = db.dao()

    fun todos() = dao.observarTodos()
    fun registro(id: Long) = dao.observar(id)
    fun items(id: Long) = dao.observarItems(id)

    suspend fun crear(preChequeo: PreChequeo): Long = db.withTransaction {
        val id = dao.insertar(preChequeo)
        dao.insertarItems(
            ChecklistBase.items.map {
                ItemChequeo(
                    preChequeoId = id,
                    categoria = it.categoria,
                    nombre = it.nombre,
                    critico = it.critico
                )
            }
        )
        id
    }

    suspend fun actualizar(preChequeo: PreChequeo) = dao.actualizar(preChequeo)
    suspend fun actualizarEstado(itemId: Long, estado: EstadoItem) =
        dao.actualizarEstado(itemId, estado)
    suspend fun actualizarObservacion(itemId: Long, texto: String) =
        dao.actualizarObservacion(itemId, texto)
    suspend fun actualizarFoto(itemId: Long, foto: String) =
        dao.actualizarFoto(itemId, foto)
    suspend fun eliminar(id: Long) = dao.eliminar(id)
}
