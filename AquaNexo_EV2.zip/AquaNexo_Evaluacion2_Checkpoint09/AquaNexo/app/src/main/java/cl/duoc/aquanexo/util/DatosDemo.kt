package cl.duoc.aquanexo.util

import cl.duoc.aquanexo.model.Rol
import cl.duoc.aquanexo.model.Usuario

data class PlantillaItem(
    val categoria: String,
    val nombre: String,
    val critico: Boolean = false
)

object ChecklistBase {
    private const val EQUIPO = "Equipamiento del buzo"
    private const val AIRE = "Compresor y suministro de aire"
    private const val EMERGENCIA = "Emergencia"
    private const val ENTORNO = "Entorno y señalización"

    val items = listOf(
        PlantillaItem(EQUIPO, "Máscara facial con comunicaciones", true),
        PlantillaItem(EQUIPO, "Regulador", true),
        PlantillaItem(EQUIPO, "Botella de emergencia", true),
        PlantillaItem(EQUIPO, "Arnés de escape rápido", true),
        PlantillaItem(EQUIPO, "Cinturón de lastro"),
        PlantillaItem(EQUIPO, "Umbilical", true),
        PlantillaItem(EQUIPO, "Profundímetro y reloj de buceo"),
        PlantillaItem(EQUIPO, "Traje, aletas y cuchillo"),
        PlantillaItem(AIRE, "Compresor operativo", true),
        PlantillaItem(AIRE, "Filtros en buen estado", true),
        PlantillaItem(AIRE, "Toma de aire del compresor"),
        PlantillaItem(AIRE, "Consola / manifold"),
        PlantillaItem(EMERGENCIA, "Buzo de emergencia disponible", true),
        PlantillaItem(EMERGENCIA, "Oxígeno de contingencia disponible", true),
        PlantillaItem(ENTORNO, "Señalización visible", true),
        PlantillaItem(ENTORNO, "Comunicaciones probadas"),
        PlantillaItem(ENTORNO, "Condiciones del mar y clima aptas")
    )
}

object DatosDemo {
    val centros = listOf(
        "Centro Demo Calbuco",
        "Centro Demo Puerto Montt",
        "Centro Demo Chiloé"
    )

    val buzos = listOf(
        "Buzo Demo 01",
        "Buzo Demo 02",
        "Buzo Demo 03",
        "Buzo Demo 04"
    )

    val usuarios = listOf(
        Usuario("Supervisor Demo", "supervisor", "1234", Rol.SUPERVISOR),
        Usuario("Jefe de Centro Demo", "admin", "1234", Rol.ADMIN)
    )
}
