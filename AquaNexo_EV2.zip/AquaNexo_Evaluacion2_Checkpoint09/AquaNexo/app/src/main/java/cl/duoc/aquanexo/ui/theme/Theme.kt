package cl.duoc.aquanexo.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val AzulProfundo = Color(0xFF0B3D62)
val Celeste = Color(0xFF00A3C4)
val Fondo = Color(0xFFF3F7F9)
val TextoOscuro = Color(0xFF0F2430)

val Verde = Color(0xFF17A75A)
val Ambar = Color(0xFFD98A00)
val Rojo = Color(0xFFDE3B40)
val Gris = Color(0xFF6B7C86)

val DegradadoMarca = Brush.linearGradient(
    listOf(AzulProfundo, Color(0xFF0E6A94), Celeste)
)

private val Esquema = lightColorScheme(
    primary = AzulProfundo,
    onPrimary = Color.White,
    secondary = Celeste,
    background = Fondo,
    onBackground = TextoOscuro,
    surface = Color.White,
    onSurface = TextoOscuro,
    error = Rojo,
    onError = Color.White
)

private val Formas = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Esquema,
        shapes = Formas,
        content = content
    )
}
