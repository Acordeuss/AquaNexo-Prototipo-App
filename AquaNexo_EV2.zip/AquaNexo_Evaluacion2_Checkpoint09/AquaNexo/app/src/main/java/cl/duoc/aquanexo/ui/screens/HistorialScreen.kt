package cl.duoc.aquanexo.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import cl.duoc.aquanexo.model.Resultado
import cl.duoc.aquanexo.ui.components.AppTopBar
import cl.duoc.aquanexo.ui.components.BarraInferior
import cl.duoc.aquanexo.ui.components.RegistroCard
import cl.duoc.aquanexo.viewmodel.HistorialViewModel

@Composable
fun HistorialScreen(
    onInicio: () -> Unit,
    onDetalle: (Long) -> Unit,
    vm: HistorialViewModel = viewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { AppTopBar("Historial") },
        bottomBar = {
            BarraInferior(
                seleccion = 1,
                onInicio = onInicio,
                onHistorial = {}
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            OutlinedTextField(
                value = state.busqueda,
                onValueChange = vm::buscar,
                label = { Text("Buscar por buzo, centro o fecha") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            )

            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = state.filtro == null,
                    onClick = { vm.filtrar(null) },
                    label = { Text("Todos") }
                )

                Resultado.entries.forEach { resultado ->
                    FilterChip(
                        selected = state.filtro == resultado,
                        onClick = { vm.filtrar(resultado) },
                        label = { Text(resultado.etiqueta) }
                    )
                }
            }

            if (state.visibles.isEmpty()) {
                Text(
                    "No hay registros que coincidan.",
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.visibles, key = { it.id }) { registro ->
                    RegistroCard(registro) { onDetalle(registro.id) }
                }
            }
        }
    }
}
