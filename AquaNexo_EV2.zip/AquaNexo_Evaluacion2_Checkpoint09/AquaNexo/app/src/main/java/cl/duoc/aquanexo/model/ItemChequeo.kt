package cl.duoc.aquanexo.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "items_chequeo",
    foreignKeys = [
        ForeignKey(
            entity = PreChequeo::class,
            parentColumns = ["id"],
            childColumns = ["preChequeoId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("preChequeoId")]
)
data class ItemChequeo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val preChequeoId: Long,
    val categoria: String,
    val nombre: String,
    val critico: Boolean,
    val estado: EstadoItem = EstadoItem.PENDIENTE,
    val observacion: String = "",
    val fotoUri: String = ""
)
