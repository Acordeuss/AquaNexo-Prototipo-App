package cl.duoc.aquanexo.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pre_chequeos")
data class PreChequeo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val centro: String,
    val fecha: String,
    val hora: String,
    val buzo: String,
    val supervisor: String,
    val saludRegistrada: Boolean = false,
    val sistolica: Int? = null,
    val diastolica: Int? = null,
    val saturacion: Int? = null,
    val pulso: Int? = null,
    val sintomas: Boolean = false,
    val malDescanso: Boolean = false,
    val medicamentos: Boolean = false,
    val resultado: Resultado? = null,
    val cerrado: Boolean = false,
    val postCompletado: Boolean = false,
    val postCondicion: String = "",
    val postSaturacion: Int? = null,
    val postObservacion: String = ""
)
