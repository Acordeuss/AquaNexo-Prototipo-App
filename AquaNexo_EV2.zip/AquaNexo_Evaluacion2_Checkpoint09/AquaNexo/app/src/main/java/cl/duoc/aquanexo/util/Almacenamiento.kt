package cl.duoc.aquanexo.util

import android.content.Context
import android.net.Uri
import java.io.File

/** Manejo simple de fotografías de evidencia en el almacenamiento privado de la app. */
object Almacenamiento {
    fun nuevoArchivo(context: Context): File {
        val carpeta = File(context.filesDir, "evidencias").apply { mkdirs() }
        return File(carpeta, "foto_${System.currentTimeMillis()}.jpg")
    }

    fun comoTexto(archivo: File): String = Uri.fromFile(archivo).toString()

    fun copiarDesdeGaleria(context: Context, origen: Uri): String? {
        val destino = nuevoArchivo(context)
        val entrada = context.contentResolver.openInputStream(origen) ?: return null
        entrada.use { input ->
            destino.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return comoTexto(destino)
    }
}
