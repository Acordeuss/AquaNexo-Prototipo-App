package cl.duoc.aquanexo.model

enum class EstadoItem(val etiqueta: String) {
    PENDIENTE("Pendiente"),
    CUMPLE("Cumple"),
    OBSERVADO("Observado"),
    NO_CUMPLE("No cumple"),
    NO_APLICA("No aplica")
}

enum class Resultado(val etiqueta: String) {
    CUMPLE("Cumple"),
    OBSERVADO("Observado"),
    REQUIERE_REVISION("Requiere revisión")
}

enum class NivelSalud(val etiqueta: String) {
    OK("Normal"),
    ALERTA("Atención"),
    CRITICO("Crítico")
}

enum class Rol(val etiqueta: String) {
    SUPERVISOR("Supervisor de buceo"),
    ADMIN("Jefe de centro / Admin")
}
