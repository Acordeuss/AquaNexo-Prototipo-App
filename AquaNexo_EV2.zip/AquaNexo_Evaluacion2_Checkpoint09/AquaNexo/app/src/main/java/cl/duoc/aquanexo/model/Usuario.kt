package cl.duoc.aquanexo.model

data class Usuario(
    val nombre: String,
    val usuario: String,
    val clave: String,
    val rol: Rol
)
