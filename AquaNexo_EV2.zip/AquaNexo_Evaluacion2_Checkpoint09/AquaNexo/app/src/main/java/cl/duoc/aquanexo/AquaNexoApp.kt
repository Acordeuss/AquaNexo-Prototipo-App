package cl.duoc.aquanexo

import android.app.Application
import cl.duoc.aquanexo.data.local.AquaNexoDatabase
import cl.duoc.aquanexo.data.repository.PreChequeoRepository

class AquaNexoApp : Application() {
    val repositorio by lazy {
        PreChequeoRepository(AquaNexoDatabase.obtener(this))
    }
}
