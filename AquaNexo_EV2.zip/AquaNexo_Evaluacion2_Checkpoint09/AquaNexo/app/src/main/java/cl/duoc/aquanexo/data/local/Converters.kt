package cl.duoc.aquanexo.data.local

import androidx.room.TypeConverter
import cl.duoc.aquanexo.model.EstadoItem
import cl.duoc.aquanexo.model.Resultado

class Converters {
    @TypeConverter
    fun deEstado(estado: EstadoItem): String = estado.name

    @TypeConverter
    fun aEstado(texto: String): EstadoItem = EstadoItem.valueOf(texto)

    @TypeConverter
    fun deResultado(resultado: Resultado?): String? = resultado?.name

    @TypeConverter
    fun aResultado(texto: String?): Resultado? =
        texto?.let { Resultado.valueOf(it) }
}
