# Diseño AquaNexo

Carpeta destinada a identidad visual, UML e interfaces.

Archivos objetivo:

```text
logo.png
flujo-usuario-uml.png
interfaces/
```

No reutilizar automáticamente la identidad visual anterior: la identidad de AquaNexo debe validarse antes de incorporarse.
