# Interfaces pendientes

- [ ] `01_login.png`
- [ ] `02_dashboard.png`
- [ ] `03_ast.png`
- [ ] `04_checklist.png`
- [ ] `05_salud.png`
- [ ] `06_evidencias.png`
- [ ] `07_dictamen.png`
- [ ] `08_historial.png`
