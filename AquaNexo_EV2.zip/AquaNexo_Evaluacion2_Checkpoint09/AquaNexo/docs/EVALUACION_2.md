# Evaluación 2 — Checklist de cierre

El alcance de esta evaluación termina en el **checkpoint 09**.

## Estado técnico

- [x] 01 — Proyecto base preparado
- [x] 02 — Modelos y reglas implementados
- [x] 03 — Tema y componentes implementados
- [x] 04 — Room implementado
- [x] 05 — Login, navegación e inicio implementados
- [x] 06 — Nuevo pre-chequeo + checklist + evidencias implementados
- [x] 07 — Salud del buzo implementada
- [x] 08 — Resultado + detalle implementados
- [x] 09 — Post-chequeo + historial implementados

## Verificación que todavía debe hacerse en Android Studio

- [ ] Gradle Sync sin errores
- [ ] Build / Make Project sin errores
- [ ] Login supervisor correcto
- [ ] Login admin correcto
- [ ] Validaciones del formulario funcionan
- [ ] Checklist bloquea avance si quedan pendientes
- [ ] Observado / No cumple exige observación
- [ ] Galería o cámara adjunta evidencia
- [ ] Salud valida rangos
- [ ] Resultado cambia según el escenario
- [ ] Room conserva registros al cerrar la app
- [ ] Historial busca y filtra
- [ ] Admin no ve acciones de edición

## Fuera de esta evaluación

- Checkpoint 10 — pruebas unitarias y de interfaz
- Checkpoint 11 — APK final / firmado

## Evidencia recomendada

Por checkpoint conserva:

1. una captura funcional;
2. un commit identificable;
3. una explicación corta de qué se implementó;
4. una prueba manual.
