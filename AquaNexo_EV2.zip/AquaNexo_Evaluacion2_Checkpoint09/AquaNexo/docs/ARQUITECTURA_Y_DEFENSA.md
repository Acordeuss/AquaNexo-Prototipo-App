# AquaNexo — Guía de defensa técnica

Esta guía está escrita para explicar el proyecto con conceptos de cuarto semestre, sin intentar sonar como un desarrollador senior.

## 1. ¿Por qué Jetpack Compose?

Compose permite construir las pantallas desde Kotlin utilizando funciones `@Composable`. En vez de mantener layouts XML separados, la pantalla se describe desde código y se vuelve a dibujar cuando cambia el estado.

**Respuesta corta:** “Usé Compose porque es la tecnología trabajada para construir la interfaz Android y se integra bien con StateFlow.”

## 2. ¿Qué es un ViewModel?

El ViewModel mantiene el estado y coordina acciones de una pantalla o flujo. De esta manera la lógica no queda mezclada directamente dentro de los botones y campos de Compose.

En AquaNexo hay tres principales:

- `SesionViewModel`: login y usuario activo.
- `HistorialViewModel`: registros, búsqueda y filtro.
- `PreChequeoViewModel`: creación, checklist, salud, resultado y post-chequeo.

## 3. ¿Qué hace StateFlow?

Patrón utilizado:

```kotlin
private val _uiState = MutableStateFlow(...)
val uiState: StateFlow<...> = _uiState.asStateFlow()
```

`_uiState` es privado y mutable porque el ViewModel es quien debe modificarlo. `uiState` es público pero de solo lectura para que Compose lo observe.

**Respuesta corta:** “Cuando cambia el StateFlow, Compose recibe el nuevo estado y actualiza la pantalla.”

## 4. ¿Por qué las validaciones están en Reglas.kt?

`Reglas.kt` contiene funciones para validar formularios, salud, checklist, post-chequeo y calcular el resultado.

Esto evita tener expresiones largas dentro de cada pantalla y hace que una misma regla pueda reutilizarse.

Ejemplo del flujo:

```text
Pantalla → ViewModel → Reglas.validar... → mapa de errores → Pantalla
```

## 5. ¿Qué es Room?

Room es la capa de persistencia local utilizada sobre SQLite.

En AquaNexo:

- `PreChequeo` e `ItemChequeo` son entidades.
- `PreChequeoDao` define consultas y operaciones.
- `AquaNexoDatabase` crea la base.
- `PreChequeoRepository` centraliza el acceso desde los ViewModels.

**Respuesta corta:** “Elegimos Room porque el MVP necesita funcionar localmente y conservar los registros aunque se cierre la aplicación.”

## 6. ¿Qué es un DAO?

DAO significa *Data Access Object*. Es la interfaz donde están las operaciones que Room puede ejecutar, por ejemplo insertar, actualizar, eliminar u observar registros.

La UI nunca habla directamente con el DAO.

## 7. ¿Para qué sirve Repository?

El Repository se encuentra entre ViewModel y Room.

```text
Compose → ViewModel → Repository → DAO → Room
```

Así el ViewModel solicita datos sin conocer los detalles de cómo se guardan.

No usamos una librería compleja de inyección de dependencias porque para el nivel y tamaño de este MVP no era necesaria.

## 8. ¿Cómo funciona la relación entre pre-chequeo e ítems?

Un `PreChequeo` representa una faena. Cada pre-chequeo tiene varios `ItemChequeo`.

`ItemChequeo` guarda `preChequeoId` como clave foránea. Si se elimina un borrador, Room utiliza `CASCADE` para eliminar sus ítems relacionados.

## 9. ¿Cómo funcionan los filtros?

Room entrega la lista de registros al `HistorialViewModel`. El `UiState` contiene:

- `registros`;
- `busqueda`;
- `filtro`.

La propiedad `visibles` aplica `filter()` buscando por buzo, centro o fecha y puede limitar por resultado.

**Respuesta corta:** “No modifico la base al escribir. Filtro la lista observada y StateFlow hace que Compose muestre el resultado.”

## 10. ¿Cómo funciona Navigation?

Las rutas están centralizadas en `Rutas` dentro de `AppNavigation.kt`.

Los registros se identifican por id:

```text
checklist/{id}
salud/{id}
resultado/{id}
detalle/{id}
post/{id}
```

Esto permite abrir el registro correcto en cada pantalla.

## 11. ¿Cómo se obtiene el resultado preliminar?

La lógica está en `Reglas.calcularResultado()`:

- ítem crítico en “No cumple” o salud crítica → **Requiere revisión**;
- observación, no cumple no crítico o salud en alerta → **Observado**;
- resto → **Cumple**.

Es un resultado académico y ficticio. La aplicación no autoriza una faena real.

## 12. ¿Por qué hay dos roles?

Para mantener el MVP alcanzable:

- Supervisor puede crear y completar registros.
- Admin / Jefe de centro consulta.

La separación se nota principalmente en el botón de nuevo pre-chequeo y en las acciones disponibles en el detalle.

## 13. ¿Cómo funcionan las fotografías?

AquaNexo puede abrir la cámara del sistema o el selector de imágenes. La ruta se guarda en el ítem correspondiente.

Las imágenes se copian a la carpeta privada de la aplicación para no depender permanentemente de un permiso temporal de galería.

## 14. ¿Qué todavía NO corresponde a esta evaluación?

Los checkpoints 10 y 11 quedan para la evaluación final:

- pruebas formales con JUnit / Compose UI Test;
- generación y firma del APK final.

## 15. Explicación de 30 segundos

“AquaNexo es un MVP Android offline-first para digitalizar el pre-chequeo de una faena de buceo. La interfaz está hecha con Jetpack Compose. Uso ViewModel y StateFlow para separar y manejar el estado, Room para guardar localmente los registros, y una clase de reglas para las validaciones y el resultado preliminar. El supervisor puede completar el flujo y el jefe de centro puede consultar el historial. Para esta segunda evaluación desarrollé hasta la integración de post-chequeo e historial; testing formal y APK quedan para la evaluación final.”
